package hu.bme.aut.android.spaceinspector.network

object NasaApiKey {
    val apiKey = "Rp0GhssI8XKHGefslljb5aWc51eBT0oseVIAu4zR"
}