package hu.bme.aut.android.spaceinspector.model.image

data class LinkX(
    val href: String,
    val prompt: String,
    val rel: String
)