package hu.bme.aut.android.spaceinspector.model.neows.neo

data class OrbitClass(
    val orbit_class_description: String,
    val orbit_class_range: String,
    val orbit_class_type: String
)