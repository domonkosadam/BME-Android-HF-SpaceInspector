package hu.bme.aut.android.spaceinspector.model.neows.neo

data class Links(
    val self: String
)