package hu.bme.aut.android.spaceinspector.model.marsrover

data class Camera(
    val full_name: String,
    val id: Int,
    val name: String,
    val rover_id: Int
)