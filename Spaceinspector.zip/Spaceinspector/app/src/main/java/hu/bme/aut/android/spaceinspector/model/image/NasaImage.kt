package hu.bme.aut.android.spaceinspector.model.image

data class NasaImage(
    val collection: Collection
)