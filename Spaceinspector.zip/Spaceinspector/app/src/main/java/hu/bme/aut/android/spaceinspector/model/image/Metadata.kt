package hu.bme.aut.android.spaceinspector.model.image

data class Metadata(
    val total_hits: Int
)