package hu.bme.aut.android.spaceinspector.viewmodel

class NasaImagesDetailsFragmentViewModel {
}