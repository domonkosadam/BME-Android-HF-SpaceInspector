package hu.bme.aut.android.spaceinspector.model.neows.browse

data class Meters(
    val estimated_diameter_max: Double,
    val estimated_diameter_min: Double
)