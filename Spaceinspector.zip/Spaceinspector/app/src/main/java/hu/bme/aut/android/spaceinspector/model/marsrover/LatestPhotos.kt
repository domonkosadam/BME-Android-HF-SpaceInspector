package hu.bme.aut.android.spaceinspector.model.marsrover

class LatestPhotos {
    var latest_photos: MutableList<MarsRoverImage> = mutableListOf()
}