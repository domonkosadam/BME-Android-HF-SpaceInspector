package hu.bme.aut.android.spaceinspector.model.neows.browse

data class Links(
    val next: String?,
    val prev: String?,
    val self: String
)