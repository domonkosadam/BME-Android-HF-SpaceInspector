package hu.bme.aut.android.spaceinspector.model.image

data class Link(
    val href: String?,
    val rel: String?,
    val render: String?
)