package hu.bme.aut.android.spaceinspector.model.neows.browse

data class EstimatedDiameter(
    val feet: Feet,
    val kilometers: Kilometers,
    val meters: Meters,
    val miles: Miles
)