package hu.bme.aut.android.spaceinspector.model.neows.neo

data class MissDistance(
    val astronomical: String,
    val kilometers: String,
    val lunar: String,
    val miles: String
)