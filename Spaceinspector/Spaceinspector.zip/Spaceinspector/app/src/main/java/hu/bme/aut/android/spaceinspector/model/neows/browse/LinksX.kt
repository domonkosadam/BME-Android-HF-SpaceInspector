package hu.bme.aut.android.spaceinspector.model.neows.browse

data class LinksX(
    val self: String
)