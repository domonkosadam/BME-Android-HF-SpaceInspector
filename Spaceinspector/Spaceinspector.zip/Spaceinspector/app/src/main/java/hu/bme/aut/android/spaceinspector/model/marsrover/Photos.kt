package hu.bme.aut.android.spaceinspector.model.marsrover

class Photos {
    var photos: MutableList<MarsRoverImage> = mutableListOf()
}