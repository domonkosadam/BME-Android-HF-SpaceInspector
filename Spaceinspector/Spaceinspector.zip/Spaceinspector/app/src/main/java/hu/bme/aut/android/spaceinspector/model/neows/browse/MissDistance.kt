package hu.bme.aut.android.spaceinspector.model.neows.browse

data class MissDistance(
    val astronomical: String,
    val kilometers: String,
    val lunar: String,
    val miles: String
)