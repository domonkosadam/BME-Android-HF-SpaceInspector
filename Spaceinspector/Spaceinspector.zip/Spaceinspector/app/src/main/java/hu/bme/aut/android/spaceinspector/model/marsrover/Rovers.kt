package hu.bme.aut.android.spaceinspector.model.marsrover

class Rovers {
    val rovers:MutableList<RoverDetails> = mutableListOf()
}