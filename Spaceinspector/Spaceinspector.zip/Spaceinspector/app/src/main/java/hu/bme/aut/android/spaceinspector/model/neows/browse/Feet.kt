package hu.bme.aut.android.spaceinspector.model.neows.browse

data class Feet(
    val estimated_diameter_max: Double,
    val estimated_diameter_min: Double
)